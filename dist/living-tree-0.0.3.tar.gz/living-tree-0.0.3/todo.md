# Todo

- [ ] `update_value` using bottom-up node id order
- [ ] method `get_top_down_ids(max_level = -1)`: 
- [ ] method `get_bottom_up_ids`: 
- [ ] method `get_ids_by_level`: 
- [ ] method `get_paths_to_level(level = -1)`: 

